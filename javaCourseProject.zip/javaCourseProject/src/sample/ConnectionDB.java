package sample;

import java.sql.*;

public class ConnectionDB {
    public static Connection getConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/javaproject";
            String username = "root";
            String password = "root";
            Connection connection = DriverManager.getConnection(url, username, password);
            return connection;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
