package sample;

import java.sql.*;
import java.util.*;

public class Other_Methods {
    public static String quarter(int n) {
        switch (n) {
            case 0:
                return "First";
            case 3:
                return "Second";
            case 6:
                return "Third";
            case 9:
                return "Fourth";
        }
        return "";
    }

    public static void wrongLog() {
        System.out.println("Apologies, but we could not find an account with such login or password, please repeat.");
    }

    public static String createCode() {
        Random random = new Random();
        String alphabet = "abcdefghijklmnopqrustuwxyz";
        String password = "";
        password += String.valueOf(random.nextInt(10));
        password += String.valueOf(random.nextInt(10));
        password += String.valueOf(random.nextInt(10));
        password += alphabet.charAt(random.nextInt(26));
        password += alphabet.charAt(random.nextInt(26));
        password += alphabet.charAt(random.nextInt(26));
        password += String.valueOf(random.nextInt(10));
        password += String.valueOf(random.nextInt(10));
        password += String.valueOf(random.nextInt(10));
        return password;
    }

    public static String month(int n) {
        switch (n) {
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "August";
            case 9:
                return "September";
            case 10:
                return "October";
            case 11:
                return "November";
            case 12:
                return "December";
        }
        return "";
    }

    public static ArrayList<ArrayList<String>> getData(Connection connection, String at) throws Exception {
        Statement stmt = connection.createStatement();
        ArrayList<ArrayList<String>> list = new ArrayList<>();
        if (at.equals("w")) {
            ResultSet resultset = stmt.executeQuery("select * from bankworker");
            while (resultset.next()) {
                ArrayList<String> l = new ArrayList<>();
                l.add(String.valueOf(resultset.getInt("bankworker_id")));
                l.add(resultset.getString("Fname"));
                l.add(resultset.getString("Lname"));
                l.add(resultset.getString("Login"));
                l.add(resultset.getString("Password"));
                list.add(l);
            }
        } else if (at.equals("c")) {
            ResultSet resultset = stmt.executeQuery("select * from client");
            while (resultset.next()) {
                ArrayList<String> l = new ArrayList<>();
                l.add(String.valueOf(resultset.getInt("client_id")));
                l.add(resultset.getString("Fname"));
                l.add(resultset.getString("Lname"));
                l.add(resultset.getString("Login"));
                l.add(resultset.getString("Password"));
                l.add(String.valueOf(resultset.getDouble("money_som")));
                l.add(String.valueOf(resultset.getDouble("money_dollar")));
                list.add(l);
            }
        }
        return list;
    }
}
